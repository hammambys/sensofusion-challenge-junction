The drone tracker is intended to use with any .dat data from an event camera. The footage "drone_moving.dat" from the challenge files provided is the data it has been developed with. You can find "drone_moving.dat" here: https://drive.google.com/drive/folders/1Hr6JhJ_lnQQ6awKyVGoYR_Ct0QvaVwM2?usp=drive_link 

The file is intended to be used as the first parameter when running the detector
-Pietu